package br.com.maximilhas.objects;

import org.openqa.selenium.By;

public class ObjectsPagePesquisaPassagens {
	//identificação do elemento
	public static By campoCidadeOuAeroportoOrigemDado = By.id("fake_input_search_from");
	//caixa do campo identificação do elemento
	public static By campoCidadeOuAeroportoOrigem = By.id("search_form_from");
	//opção lista do campo identificação do elemento
	public static By campoCidadeOuAeroportoOrigemSelecao = By.cssSelector("#search_form_from_wrapper > div > div > div:nth-child(3) > div");
	

	public static By campoCidadeOuAeroportoDestinoDado = By.id("fake_input_search_to");
	public static By campoCidadeOuAeroportoDestino = By.id("search_form_to");	
	public static By campoCidadeOuAeroportoDestinoSelecao = By.cssSelector("#search_form_to_wrapper > div > div > div > div");
	
	public static By botaoPesquisar = By.id("btn_search_flights");


	public static By popUpAtivarNotificacaoes = By.id("onesignal-popover-cancel-button");
}
