package br.com.maximilhas.suites;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import br.com.maximilhas.tests.PagePesquisaPassagensTest;
import br.com.maximilhas.utils.DriverUtil;

@RunWith(Suite.class)
@SuiteClasses({

		PagePesquisaPassagensTest.class,

})
public class SuiteMaxMilhas extends DriverUtil {

	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver", "../maxmilhas/2.40/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		setDriver(new ChromeDriver(options));
		getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		getDriver().get("https://www-qa.maxmilhas.com.br/");
	}

	@AfterClass
	public static void tearDown() {
		if (getDriver() != null) {
			getDriver().quit();
		}
	}
}
