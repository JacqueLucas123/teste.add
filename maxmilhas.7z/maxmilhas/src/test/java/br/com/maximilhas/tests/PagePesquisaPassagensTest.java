package br.com.maximilhas.tests;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import br.com.maximilhas.objects.ObjectsPagePesquisaPassagens;
import br.com.maximilhas.utils.MetodosUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PagePesquisaPassagensTest extends MetodosUtil {
	@Test
	public void p10FecharPopUpAtivarNotificacaoes() {
		clicar(ObjectsPagePesquisaPassagens.popUpAtivarNotificacaoes);
	}

	@Test
	public void p20InformarCidadeOuAeroportoOrigem() {
		clicar(ObjectsPagePesquisaPassagens.campoCidadeOuAeroportoOrigemDado);
		informarTexto(ObjectsPagePesquisaPassagens.campoCidadeOuAeroportoOrigem, "Belo Horizonte");
		clicar(ObjectsPagePesquisaPassagens.campoCidadeOuAeroportoOrigemSelecao);
	}

	@Test
	public void p30InformarCidadeOuAeroportoDestino() {
		clicar(ObjectsPagePesquisaPassagens.campoCidadeOuAeroportoDestinoDado);
		informarTexto(ObjectsPagePesquisaPassagens.campoCidadeOuAeroportoDestino, "Fortaleza");
		clicar(ObjectsPagePesquisaPassagens.campoCidadeOuAeroportoDestinoSelecao);
	}

	@Test
	public void p40acionarPesquisa() {
		clicar(ObjectsPagePesquisaPassagens.botaoPesquisar);
	}
}
