package br.com.maximilhas.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MetodosUtil extends DriverUtil {
	private static final int TEMPO_DEFAULT_ESPERA = 30;

	public static void clicar(By elemento) {
		aguardarElementoSerCarregado(elemento);
		findElement(elemento).click();
	}

	public static void informarTexto(By elemento, String texto) {
		aguardarElementoSerCarregado(elemento);
		findElement(elemento).sendKeys(texto);
	}

	private static WebElement findElement(By elemento) {
		return getDriver().findElement(elemento);
	}

	public static void aguardarElementoSerCarregado(By elemento) {
		aguardarElementoSerCarregado(TEMPO_DEFAULT_ESPERA, elemento);
	}

	public static void aguardarElementoSerCarregado(int tempoAguardar, By elemento) {
		WebDriverWait wait = new WebDriverWait(getDriver(), tempoAguardar);
		wait.until(ExpectedConditions.visibilityOfElementLocated(elemento));
	}
}
